import asyncio
import os
from datetime import datetime, timedelta
from src.integrations.fyers_client import FyersClient
from src.config.market_hours import IST

async def main():
    try:
        client = FyersClient()
        range_to = datetime.now(tz=IST).strftime("%Y-%m-%d")
        range_from = (datetime.now(tz=IST) - timedelta(days=15)).strftime("%Y-%m-%d")
        
        test_symbol = "NSE:NIFTY24APR22500CE" # Might be expired. Let's use a recent symbol.
        res = client.get_history(
            symbol=test_symbol,
            resolution="15",
            range_from=range_from,
            range_to=range_to,
            date_format=1
        )
        print("Success:", res.get("s"))
        print("Candle count:", len(res.get("candles", [])))
        if not res.get("candles"):
            print("Message:", res.get("message"))
    except Exception as e:
        print("Error:", str(e))

if __name__ == "__main__":
    asyncio.run(main())
