import asyncio
from src.integrations.fyers_client import FyersClient
import logging
from datetime import datetime, timedelta

async def test():
    client = FyersClient()
    if not client.is_authenticated:
        print("Not authenticated!")
        # Try loading
    
    symbol = "NSE:ABB26APR5950CE"
    range_from = (datetime.now() - timedelta(days=15)).strftime("%Y-%m-%d")
    range_to = datetime.now().strftime("%Y-%m-%d")
    
    try:
        res = client.get_history(
            symbol=symbol,
            resolution="15",
            range_from=range_from,
            range_to=range_to,
            date_format=1
        )
        print("History Output:", res)
    except Exception as e:
        print("Error:", repr(e))

asyncio.run(test())
