import yfinance as yf
ticker = yf.Ticker("AAPL260401C00220000") # from our previous test!
hist = ticker.history(interval="15m", period="5d")
print("Candles:", len(hist))
